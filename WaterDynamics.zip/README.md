# WaterDynamics
Project repo for CSS 458

# CA Variables

## Water states
Flowing, hot, cold, etc.
